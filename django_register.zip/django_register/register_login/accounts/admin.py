from django.contrib import admin
from .models import contactEnquiry

# Register your models here.
admin.site.register(contactEnquiry)